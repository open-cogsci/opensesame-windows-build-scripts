yolk
====

.. image:: https://travis-ci.org/myint/yolk.svg?branch=develop
    :target: https://travis-ci.org/myint/yolk
    :alt: Build status

.. contents::


Installation
------------

::

    $ pip install --upgrade yolk3k


Summary
-------

Yolk is a Python tool for obtaining information about installed Python packages
and querying packages available on PyPI (Python Package Index). ``yolk3k``
is a fork of the original ``yolk``. ``yolk3k`` add Python 3 support (while
maintaining Python 2 support). It also adds additional features.


You can see which packages are active, non-active or in development mode and
show you which have newer versions available by querying PyPI.

Usage Examples::

    $ yolk --upgrade
        Upgrade all packages

    $ yolk --upgrade --user
        Upgrade user packages

    $ yolk -l
        List all installed Python packages

    $ yolk -a
        List only the activated packages installed (Activated packages are
        normal packages on sys.path you can import)

    $ yolk -n
        List only the non-activated (--multi-version) packages installed

    $ yolk -l -f License,Author nose==1.0
        Show the license and author for version 1.0 of the package `nose`

    $ yolk --entry-map nose
        Show entry map for the nose package

    $ yolk --entry-points nose.plugins
        Show all setuptools entry points for nose.plugins


These options query PyPI::

    $ yolk -U pkg_name
        Shows if an update for pkg_name is available by querying PyPI

    $ yolk -U
         Checks PyPI to see if any installed Python packages have updates
         available.

    $ yolk -F Paste
        Download source tarball for latest version of Paste to your current
        directory

    $ yolk -F Paste -T svn
        Do a subversion checkout for Paste to a directory named Paste_svn in
        your current directory.

    $ yolk -L 2
        Show list of CheeseShop releases in the last two hours

    $ yolk -C 2
        Show detailed list of changes in the CheeseShop in the last two hours

    $ yolk -M Paste==1.0
        Show all the metadata for Paste version 1.0

    $ yolk -M Paste
        Show all the metadata for the latest version of Paste listed on PyPI

    $ yolk -D cheesecake
        Show all (source, egg, svn) URL's for the latest version of cheesecake
        packages

    $ yolk -T source -D cheesecake
        Show only source code releases for cheesecake

    $ yolk -H twisted
        Launches your web browser at Twisted's home page


Useful tips
-----------

Check invalid reStructuredText in descriptions on PyPI (using `rstcheck`_)::

    $ yolk --query-metadata=pip --fields=description | rstcheck -

.. _rstcheck: https://github.com/myint/rstcheck
